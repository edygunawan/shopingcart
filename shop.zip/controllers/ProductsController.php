<?php
namespace controllers;

use classes\Helper;
use classes\Cookie;

class ProductsController extends BaseController
{
    public function index()
    {
        $OB = new \classes\Product();
        $products = $OB->getAll();

        $this->view("products/index", [
            "products" => $products
        ]);
    }    
}
?>