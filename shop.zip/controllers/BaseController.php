<?php
namespace controllers;

use classes\Helper;

class BaseController
{
    public $__bypassLogin = false;

    public function view($viewName, $params = [])
    {
        if(sizeof($params))
        {
            extract($params);
        }

        $viewFile = dirname(__FILE__).'/../views/'.$viewName.".php";

        if(file_exists($viewFile)) {
            include $viewFile;
        }
    }
}
?>