<?php
namespace controllers;

use classes\Helper;

class IndexController extends BaseController
{
    public function index()
    {
        $this->view("index");
    }
}
?>