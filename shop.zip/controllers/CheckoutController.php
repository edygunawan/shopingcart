<?php
namespace controllers;

use classes\Helper;
use classes\Cookie;

class CheckoutController extends BaseController
{
    public function index()
    {
        # Get checkout by cookie
        $CO = new \classes\Cart();
        $carts = $CO->getByCookie();

        $this->view("checkout/index", [
            "carts" => $carts
        ]);
    }

    public function customer_form()
    {
        # Get checkout by cookie
        $CO = new \classes\Cart();
        $carts = $CO->getByCookie();

        if(!empty($carts)) {
            $this->view("checkout/customer_form", [
                "carts" => $carts
            ]);
        }
        else {
            header("Location: /");
        }     
    }

    public function complete_order()
    {
        $out=[
            "ack" => "error"
        ];

        if(!empty($_POST["inputName"]) && !empty($_POST["inputEmail"])) {
            $customer = new \classes\Customer();
            $customer->name = $_POST["inputName"];
            $customer->email = $_POST["inputEmail"];
            $customer->save();

            if(!empty($customer->id)) {
                $CO = new \classes\Checkout();
                $checkout = $CO->getByCookie();

                if(!empty($checkout->id)) {
                    $checkout->customer = $customer->id;
                    $checkout->save();

                    # Remove checkout cookie
                    $cookie = new Cookie("checkout");
                    $cookie->removeCookie();

                    $out=[
                        "ack" => "success"
                    ];
                }
            }
        }

        echo json_encode($out);
    }

    public function add_to_cart()
    {
        $out=[
            "ack" => "error"
        ];

        $OB = new \classes\Product();
        $product = $OB->find($_POST["id"]);
        
        if(!empty($product)) {

            # Insert cart item
            $cart = new \classes\Cart();
            $cart->product = $product->id;
            $cart->qty = 1;
            $cart->save();

            if($cart->id) {
                # Get checkout by cookie
                $CO = new \classes\Checkout();
                $checkout = $CO->getByCookie();
                $carts = [];

                if(empty($checkout)) {
                    $checkout = $CO;
                }

                if(!empty($checkout->carts)) {
                    $carts = json_decode($checkout->carts, true);
                }

                $carts[] = $cart->id;
                $checkout->carts = json_encode($carts);                

                $checkout->customer = 0;                
                $checkout->save();

                if($checkout->id) {
                    $cookie = new Cookie("checkout");
                    $cookie->setCookie($checkout->id);

                    $out=[
                        "ack" => "success"
                    ];
                }        
            }
        }

        echo json_encode($out);
    }

    public function ajax_count_cart_item()
    {
        $CO = new \classes\Cart();
        $carts = $CO->getByCookie();

        if(!empty($carts)) {
            echo json_encode(array_keys($carts));
        }
        else {
            echo json_encode([]);
        }
    }

    public function delete_cart()
    {
        $out=[
            "ack" => "error"
        ];

        if(!empty($_POST["cartId"])) {
            $CO = new \classes\Cart();
            $CO->deleteCart($_POST["cartId"]);

            $out=[
                "ack" => "success"
            ];
        }

        echo json_encode($out);
    }
}