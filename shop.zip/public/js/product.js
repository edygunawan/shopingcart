(function($){
    function update_notif(){
        $.post("/checkout/ajax_count_cart_item", {}, function(result){
            if(result) {
                $("#cart_notif").html(result.length);
            }
        }, "json");
    }

    $(document).ready(function(){
        update_notif();

        $(".add_to_cart").click(function(){
            $.post("/checkout/add_to_cart", {id:$(this).attr("product-id")}, function(result){
                if(result.ack == "success") {
                    $.notify("Cart updated", "success");
                    update_notif();
                }
                else {
                    $.notify("Cart updated", "error");
                }
            }, "json");
        });

        $("#submit_order").click(function(){
            var form = $(this).closest("form");

            $.post(form.attr("action"), form.serialize(), function(result){
                if(result.ack == "success") {
                    $.notify("Order completed", "success");
                    update_notif();
                }
                else {
                    $.notify("Can't complete order", "error");
                }
            }, "json");
        });

        $(".delete_cart").click(function(){
            $.post("/checkout/delete_cart", {cartId:$(this).attr("cart-id")}, function(result){
                if(result.ack == "success") {
                    $.notify("Cart deleted", "success");
                    window.location.reload();
                }
                else {
                    $.notify("Can't delete cart", "error");
                }
            }, "json");
        });
    });
})(jQuery);