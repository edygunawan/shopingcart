<?php
namespace classes;

use classes\DB;
use classes\Helper;
use classes\Cookie;

class Checkout extends Object
{
    public $__table = "checkout";

    public function getByCookie()
    {
        $cookie = new Cookie("checkout");
        $checkoutCookie = $cookie->getCookie();

        if(!empty($checkoutCookie)) {
            return $this->find($checkoutCookie);
        }
        else {
            return null;
        }
    }
}
?>