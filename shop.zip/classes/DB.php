<?php
namespace classes;

use classes\Helper;

class DB 
{
    public $__connection;

    public function __construct($args = [])
    {
        if(isset($args["host"]) && isset($args["username"]) && isset($args["password"]) && isset($args["database"])){
            $port = 3306;

            if(!empty($args["port"])) {
                $port = $args["port"];
            }

            $conn = new \mysqli($args["host"], $args["username"], $args["password"], $args["database"]);

            if ($conn->connect_errno)
            {
                printf("Connect failed: %s\n", $conn->connect_error);
                exit();
            }
            else {
                $this->__connection = $conn;
            }
        }
    }

    public function query($query)
    {
        try {
            $res = $this->__connection->query($query);

            if($res === true) {
                return $this->__connection->insert_id;
            }
            else {
                $out = [];

                while ($row = $res->fetch_assoc()) {
                    $out[] = $row;
                }

                return $out;
            }
        } catch (Exception $e) {
            return null;
        }
    }
}
?>