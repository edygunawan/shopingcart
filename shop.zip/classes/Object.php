<?php
namespace classes;

use classes\DB;
use classes\Helper;

class Object {
    public $__DB;
    public $__attributes;
    public $__table;
    public $__primaryKey = "id";

    public function __construct($args = [])
    {
        $config = Helper::getDBConfig();
        
        if(!empty($config["main"])) {
            $this->__DB = new DB($config["main"]);
        }

        if(!empty($args["table"])) {
            $this->__table = $args["table"];
        }
        
        $this->__attributes = $this->getAttributes();

        if(!empty($this->__attributes)) {
            foreach($this->__attributes as $attrib => $detail)
            {
                $this->$attrib = "";
            }
        }
    }

    public function getAttributes()
    {
        $columns = [];

        if(!empty($this->__table)) {
            $query = "SHOW COLUMNS FROM ".$this->__table;        
            $result = $this->__DB->query($query);

            if(sizeof($result))
            {
                foreach($result as $key => $item)
                {
                    $columns[$item["Field"]] = $item;
                }
            }
            
            return $columns;
        }
    }

    public function save() {
        $save = [];

        if(!empty($this->__attributes)) {            
            $values = [];
            $keys = [];
            $updateString = [];
            $primary = $this->__primaryKey;

            foreach($this->__attributes as $attrib => $detail){
                if($attrib == $primary) continue;

                $keys[] = "`".$this->__table."`.`".$attrib."`";

                if($this->$attrib === "" && $detail["Null"] != "NO") {
                    $values[] = "NULL";
                    $updateString[] ="`".$this->__table."`.`".$attrib."`= NULL";	
                }
                else {
                    $values[] = "'".$this->$attrib."'";
                    $updateString[] ="`".$this->__table."`.`".$attrib."`='".$this->$attrib."'";
                }
            }

            $keys = "(".implode(",", $keys).")";
            $vals = " VALUES (".implode(",", $values).")";

            if($this->$primary) {
                $query = "UPDATE `".$this->__table."` SET ".implode(", ", $updateString)." WHERE `".$this->__table."`.`".$primary."` = '".$this->$primary."'";
                $this->__DB->query($query);               
            }
            else {
                $query = "INSERT INTO `".$this->__table."` ".$keys.$vals;
                $this->$primary = $this->__DB->query($query);
            }
        }
    }

    public function insert($insert)
    {
        foreach ($insert as $key => $val) {
            # Check valid fields
            if(array_key_exists($key, $this->__attributes)) {
                $this->$key = $val;
            }
        }
        
        $this->save();
    }

    public function delete()
    {
        $primary = $this->__primaryKey;

        if($this->$primary) {
            $this->__DB->query("DELETE FROM `".$this->__table."` WHERE `".$this->__table."`.`id` = '".$this->$primary."'");

            return true;
        }
        else {
            return false;
        }
    }

    public function find($id) {
        $out = null;

        if($id) {            
            $res = $this->__DB->query("SELECT * FROM `".$this->__table."` WHERE `".$this->__table."`.`id` = '".$id."'");

            if(!empty($res[0])){
                foreach($res[0] as $key => $val) {
                    if(array_key_exists($key, $this->__attributes)) {
                        $this->$key = $val;
                    }
                }
            }

            $out = $this;
        }

        return $out;
    }

    public function all()
    {
        $res = $this->__DB->query("SELECT * FROM `".$this->__table."`");

        if(sizeof($res)) 
        {
            $out = [];

            foreach($res as $ig => $arr) {
                $out[] = $arr;                
            }

            return $out; 
        }
        else
        {
            return null;
        }
    }

    public function where($where)
    {
        if(!empty($where)) {
            $res = $this->__DB->query("SELECT * FROM `".$this->__table."` WHERE ".$where);

            if(sizeof($res)) {
                $out = [];

                foreach($res as $ig => $arr) {
                    $out[] = $arr;                
                }

                return $out; 
            }
            else {
                return null;
            }
        }
        else {
            return null;
        }
    }
}
?>