<?php
namespace classes;

class Helper {
    public static function debug($arr)
    {
        echo "<pre>";
        print_r($arr);
        echo "</pre>";
    }

    public static function getDBConfig($file = 'database.json')
    {
        if ($file == 'database.json' && getenv('DB_CONFIG_FILE')) {
            $file = getenv('DB_CONFIG_FILE');
        }
        
        try {
            $json = file_get_contents('../config/'.$file);
            return json_decode($json, true);
        } catch (Exception $e) {
            return false;
        } 
    }
}
?>