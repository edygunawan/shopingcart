<?php
namespace classes;

use classes\Helper;

class App
{
    public function run()
    {
        $RC = new \classes\Routing();
        $route = $RC->getRoute();

        /* Get controller and method name */
        if(!empty($route["namespace"])) {
            $cName = $route["namespace"]."\\".ucfirst($route["controller"])."Controller";
        }
        else {
            $cName = "\\controllers\\".ucfirst($route["controller"])."Controller";
        }
        
        $mName = $route["method"];
    
        /* initiate the controller */
        try {
           if(class_exists($cName))
           {                
                $control = new $cName();

                if(method_exists($control, $mName)) {
                    if(isset($route["param"]) && !empty($route["param"]))
                    {
                        $control->$mName($route["param"]);
                    }
                    else
                    {
                        $control->$mName();
                    }
                }
                else {
                    header("HTTP/1.0 404 Not Found");
                    exit();
                }
           }
           else {
                header("HTTP/1.0 404 Not Found");
                exit();
            }         
        } catch (Exception $e) {
            echo $e->getMessage(), "\n";
            exit();
        }
    }
}
?>