<?php
namespace classes;

use classes\DB;
use classes\Helper;

class User extends Object
{
    public $__table = "users";
}
?>