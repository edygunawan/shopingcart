<?php
namespace classes;

use classes\DB;
use classes\Helper;

class Cart extends Object
{
    public $__table = "cart";

    public function getByCookie()
    {
        $CO = new \classes\Checkout();
        $checkout = $CO->getByCookie();

        if(!empty($checkout->carts)) {
            # Get all Products
            $PO = new \classes\Product();
            $res = $PO->all();
            $products = []; 
    
            if(!empty($res))
            {
                foreach($res as $key => $val)
                {
                    $products[$val["id"]] = $val;
                }
            }

            $carts = json_decode($checkout->carts, true);
            $res = $this->where("id IN('".implode("', '", $carts)."')");
            $out = [];

            if(!empty($res)) {
                foreach($res as $key => $val)
                {
                    if(!empty($products[$val["product"]])) {
                        $val["product"] = $products[$val["product"]];
                    }

                    $out[$val["id"]] = $val;
                }
            }

            return $out;
        }
        else {
            return null;
        }
    }

    public function deleteCart($cartId)
    {
        $CO = new \classes\Checkout();
        $checkout = $CO->getByCookie();

        if(!empty($checkout->carts)) {
            $carts = json_decode($checkout->carts, true);

            if (($key = array_search($cartId, $carts)) !== false) {
                unset($carts[$key]);
            }

            $checkout->carts = json_encode($carts);
            $checkout->save();

            $cartItem = $this->find($cartId);

            if(!empty($cartItem->id)) {
                $deleted = $cartItem->delete();
            }
        }
    }
}
?>