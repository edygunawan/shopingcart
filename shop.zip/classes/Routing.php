<?php
namespace classes;

use classes\Helper;

class Routing
{
    public $definedRouting = [
        "/system_admin" => [
            "namespace" => "madesoft\\fastbit\\controllers"
        ],
        "/frontend" => [
            "namespace" => "controllers",
            "controller" => "Index",
            "method" => "index",
            "param" => ""
        ]
    ];

    public function __construct($args = [])
    {
        if(!empty($args["routings"])) {
            foreach($args["routings"] as $key => $val){
                if(!isset($this->definedRouting[$key])) {
                    $this->definedRouting[$key] = $val;
                }
            }
        }        
    }
    
    public function staticRoute($uri)
    {
        if(!empty($this->definedRouting) && !empty($uri)) {
            if(array_key_exists($uri, $this->definedRouting)) {
                $routeFound = $this->definedRouting[$uri];
                $routeFound["uri"] = $uri;

                return $routeFound;
            }
            else {
                $ext = explode("/", $uri);
                unset($ext[sizeof($ext)-1]);
                
                if(sizeof($ext) > 1) {
                    $new_uri= implode("/", $ext);

                    return $this->staticRoute($new_uri);
                }
                else {
                    return false;
                }
            }
        }
        else {
            return false;
        }
    }

    public function getRoute()
    {       
        $uri = $_SERVER["REQUEST_URI"];
        $extParam = false;

        if (strpos($uri, '?') !== false) {
            $hj = explode('?', $uri);
            $uri = $hj[0];
            $extParam = $hj[1];
        }

        $staticRoutes = $this->staticRoute($uri);

        if($staticRoutes) {
            # Static routing
            $route = $staticRoutes;
            $uri = str_replace($route["uri"], "", $uri);
            $res = explode('/', $uri);
            unset($res[0]);

            if(!empty($res[1])) {
                if(empty($route["controller"])) {
                    $route["controller"] = $res[1];
                    unset($res[1]);
                }
                else if(empty($route["method"])) {
                    $route["method"] = $res[1];
                    unset($res[1]);
                }
            }
            
            if(!empty($res[2])){
                if(empty($route["method"])) {
                    $route["method"] = $res[2];
                    unset($res[2]);
                }
            }

            if(!empty($res)) {
                if(sizeof($res) == 1) {
                    $param = reset($res);
                    if(!empty($param)) {
                        $route["param"] = reset($res);
                    }                    
                }
            }
        }
        else {
            # Dynamic routing
            $res = explode('/', $uri);
            unset($res[0]);

            if(!empty($res[1])) {
                if(empty($route["controller"])) {
                    $route["controller"] = $res[1];
                    unset($res[1]);
                }
                else if(empty($route["method"])) {
                    $route["method"] = $res[1];
                    unset($res[1]);
                }
            }
            
            if(!empty($res[2])){
                if(empty($route["method"])) {
                    $route["method"] = $res[2];
                    unset($res[2]);
                }
            }

            if(!empty($res)) {
                if(sizeof($res) == 1) {
                    $param = reset($res);
                    if(!empty($param)) {
                        $route["param"] = reset($res);
                    }                    
                }
            }
        }

        if(empty($route["controller"])) {
            $route["controller"] = "index";
        }

        if(empty($route["method"])) {
            $route["method"] = "index";
        }

        return $route;
    }

    public function setHttpGet()
    {

    }
}
?>