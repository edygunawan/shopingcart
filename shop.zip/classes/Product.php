<?php
namespace classes;

use classes\DB;
use classes\Helper;
use classes\Object;

class Product extends Object
{
    public $__table = "products";

    public function getAll()
    {
        $PC = new Object([
            "table" => "categoryProduct"
        ]);
        $res = $PC->all();
        $categories = []; 

        if(!empty($res))
        {
            foreach($res as $key => $val)
            {
                $categories[$val["id"]] = $val;
            }
        }

        $res = $this->all();
        $out = [];

        if(!empty($res)) {
            foreach($res as $key => $val)
            {
                if(!empty($categories[$val["category"]])) {
                    $val["category"] = $categories[$val["category"]];
                }

                $out[$val["id"]] = $val;
            }
        }

        return $out;
    }
}
?>