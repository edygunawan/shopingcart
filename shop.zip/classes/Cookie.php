<?php
namespace classes;

class Cookie {
    public $cookieName;

    public function __construct($cookieName)
    {
        $this->cookieName = $cookieName;
    }

    public function setCookie($cookie_value)
    {
        setcookie($this->cookieName, $cookie_value, time() + (86400 * 30), "/");
    }

    public function getCookie()
    {
        if(!empty($_COOKIE[$this->cookieName])) {
            return $_COOKIE[$this->cookieName];
        }
        else {
            return false;
        }
    }

    public function removeCookie()
    {
        setcookie($this->cookieName, "", time() - 3600, "/");
    }
}
?>