<?php
# Static loader to DOCUMENT_ROOT/../
spl_autoload_register(function ($className) {
    $base = $_SERVER['DOCUMENT_ROOT'] .'/..';
    
    if(strpos($className, "\\") !== false) {
        $className = str_replace('\\', '/', $className);        
    }
    else if(strpos($className, "Controller") !== false) {
        $className = 'controllers/'.$className;
    }

    $classFile = $base.'/'.$className.".php";

    if(file_exists($classFile))
    {
        include $classFile;
    }    
});
?>