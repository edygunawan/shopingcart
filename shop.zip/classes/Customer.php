<?php
namespace classes;

use classes\DB;
use classes\Helper;

class Customer extends Object
{
    public $__table = "customers";
}
?>