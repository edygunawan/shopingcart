<?php
include dirname(__FILE__).'/header.php';
?>
<div class="container">
    <h1>Welcome to shopingcart</h1>

    <div class="row">        
        <div class="col-md-12">
            
        </div>
    </div>
</div>
<?php
include dirname(__FILE__).'/footer.php';
?>