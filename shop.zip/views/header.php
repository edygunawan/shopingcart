<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Shopingcart</title>

    <!-- Bootstrap core CSS-->
    <link href="/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/vendor/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="/css/custome.css?v=<?php echo date("U"); ?>">

    <?php
    # Append css style
    if(isset($extCSS) && !empty($extCSS)) {
        echo $extCSS;
    }
    ?>
</head>
<body id="page-top">
    <div id="wrapper">
        <div id="content-wrapper">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
                    <a class="navbar-brand" href="#">Shopingcart</a>
                    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                        <li class="nav-item active">
                            <a class="nav-link" href="/">Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/products">Products</a>
                        </li>
                    </ul>
                    <ul class="form-inline my-2 my-lg-0">
                        <!--<li class="nav-item active">
                            <a class="nav-link" href="#">Login</a>
                        </li>-->
                        <li class="nav-item">
                            <a class="nav-link" href="/checkout">Checkout <div id="cart_notif"></div></a>
                        </li>
                    </ul>
                </div>
            </nav>
            <div class="container-fluid bg-lightgray py-5">