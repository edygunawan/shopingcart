        </div><!-- /.container-fluid -->        
    </div><!-- /.content-wrapper -->
</div><!-- /#wrapper -->
<!-- Sticky Footer -->
<footer class="sticky-footer py-2">
    <div class="container my-auto">
        <div class="copyright text-center my-auto"><span>Copyright - shopingcart</span></div>
    </div>
</footer>

<!-- Bootstrap core JavaScript-->
<script src="/vendor/jquery/jquery.min.js"></script>
<script src="/vendor/notify/notify.min.js"></script>
<script src="/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="/js/product.js?v=<?php echo date("U"); ?>"></script>
<?php
# Append js script
if(isset($extJs) && !empty($extJs)) {
    echo $extJs;
}
?>
    </body>
</html>