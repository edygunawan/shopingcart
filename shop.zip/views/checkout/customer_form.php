<?php
include dirname(__FILE__).'/../header.php';
?>
<div class="container">
    <h1>Your detail</h1>

    <div class="row">        
        <div class="col-md-12">
            <form action="/checkout/complete_order" method="post">
                <div class="form-group">
                    <label for="inputName">Name</label>
                    <input type="text" class="form-control" id="inputName" name="inputName" placeholder="Name">
                </div>
                <div class="form-group">
                    <label for="inputEmail">Email address</label>
                    <input type="email" class="form-control" id="inputEmail" name="inputEmail" aria-describedby="emailHelp" placeholder="Enter email">
                    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                </div>
                <button type="button" class="btn btn-primary" id="submit_order">Submit</button>
            </form>        
        </div>        
    </div>
</div>

<?php
include dirname(__FILE__).'/../footer.php';
?>