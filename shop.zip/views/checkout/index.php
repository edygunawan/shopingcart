<?php
include dirname(__FILE__).'/../header.php';
?>
<div class="container">
    <h1>Cart detail</h1>

    <div class="row">        
        <div class="col-md-12">
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Product</th>
                        <th scope="col">Qty</th>
                        <th scope="col">Price</th>
                        <th scope="col">Sub Total</th>
                        <th scope="col"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if(!empty($carts)) {
                        $x=1;
                        $qty=0;
                        $totalPrice=0;

                        foreach($carts as $id => $val) {
                            $qty = $qty+$val["qty"];
                            $subTotal = $val["qty"]*$val["product"]["price"];
                            $totalPrice = $totalPrice+$subTotal;
                    ?>
                    <tr>
                        <th scope="row"><?php echo $x++; ?></th>
                        <td><?php echo $val["product"]["name"]; ?></td>
                        <td>Rp. <?php echo number_format($val["product"]["price"],0,",","."); ?></td>
                        <td><?php echo $val["qty"]; ?></td>
                        <td>Rp. <?php echo number_format($subTotal,0,",","."); ?></td>
                        <td><i class="fa fa-trash-o delete_cart red" cart-id="<?php echo $id; ?>" aria-hidden="true"></i></td>
                    </tr>
                    <?php
                        }
                    ?>
                    <tr>
                        <th scope="row"><b>Total</b></th>
                        <td></td>
                        <td></td>
                        <td><b><?php echo $qty; ?></b></td>
                        <td><b>Rp. <?php echo number_format($totalPrice,0,",","."); ?></b></td>
                        <td></td>
                    </tr>
                    <tr>
                        <th scope="row"></th>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td><a href="/checkout/customer_form" class="btn btn-danger" id="complete_order">Complete order</a></td>
                        <td></td>
                    </tr>
                    <?php
                    }
                    ?>                    
                </tbody>
            </table>            
        </div>        
    </div>
</div>

<?php
include dirname(__FILE__).'/../footer.php';
?>