<?php
include dirname(__FILE__).'/../header.php';
?>
<div class="container">
    <h1>Products</h1>

    <div class="row">
        <?php
        if(!empty($products)) {

            foreach($products as $id => $val) {
        ?>
            <div class="col-md-4">
                <div class="products">
                    <img src="<?php echo $val["image"]; ?>">
                    <h5><?php echo $val["name"]; ?></h5>
                    <h6>Rp. <?php echo number_format($val["price"],0,",","."); ?></h6>
                    <p class="description"><?php echo $val["description"]; ?></p>
                    <div class="clear10"></div>
                    <button type="button" class="btn btn-secondary add_to_cart" product-id="<?php echo $val["id"]; ?>">Add to cart</button>
                </div>
            
            </div>
        <?php
            }
        }
        ?>
    </div>
</div>

<?php
include dirname(__FILE__).'/../footer.php';
?>